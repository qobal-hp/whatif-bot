# एनवीडिया के शेयर की खोज अचानक क्यों बढ़ी? #shorts

अवलोकन · 2026-11-24T00:51:58+05:30 (IST) · 2026-11-23T11:21:58-08:00 (PT)
घटना · 2026-11-23 · America/Los_Angeles
लक्ष्य अवधि · लगभग 27.0 सेकंड (89 शब्द)। रेंडर का समय वास्तविक आवाज़ से तय होगा।
आवाज़ · अर्जुन, भारतीय हिंदी। तेज़ लेकिन संयत न्यूज़ टोन। वापसी और प्री-मार्केट के आँकड़े पर हल्का ज़ोर दें।

## वाचन

जेनसन हुआंग लौट आए। एनवीडिया ने उन्हें फिर सी ई ओ बनाया।
बारह नवंबर को कंपनी ने उनके इस्तीफ़े की घोषणा की थी।
तेईस नवंबर को बोर्ड ने सर्वसम्मति से हुआंग को दोबारा कंपनी की कमान सौंपी।
अमेरिकी बाज़ार खुलने से पहले एनवीडिया का शेयर पिछले बंद भाव के मुकाबले पच्चीस फ़ीसदी से ज़्यादा चढ़ा।
उधर भारत में भी लोग एनवीडिया के शेयर का भाव खोज रहे थे। कर्नाटक में ख़ास दिलचस्पी दिखी।
गूगल ट्रेंड्स के मुताबिक, बीते चौबीस घंटों में इससे जुड़ी खोजें दो लाख से ज़्यादा थीं।

## वाचन और उपशीर्षक

| वाक्य | भाव | वाचन | उपशीर्षक |
|---|---|---|---|
| 1 | excited | जेनसन हुआंग लौट आए। | जेनसन हुआंग लौट आए। |
| 1 | excited | एनवीडिया ने उन्हें फिर | एनवीडिया ने उन्हें फिर |
| 1 | excited | सी ई ओ बनाया। | सीईओ बनाया। |
| 2 | normal | बारह नवंबर को | 12 नवंबर को |
| 2 | normal | कंपनी ने उनके इस्तीफ़े | कंपनी ने उनके इस्तीफ़े |
| 2 | normal | की घोषणा की थी। | की घोषणा की थी। |
| 3 | normal | तेईस नवंबर को | 23 नवंबर को |
| 3 | normal | बोर्ड ने सर्वसम्मति से | बोर्ड ने सर्वसम्मति से |
| 3 | normal | हुआंग को दोबारा | हुआंग को दोबारा |
| 3 | normal | कंपनी की कमान सौंपी। | कंपनी की कमान सौंपी। |
| 4 | excited | अमेरिकी बाज़ार खुलने से पहले | अमेरिकी बाज़ार खुलने से पहले |
| 4 | excited | एनवीडिया का शेयर | एनवीडिया का शेयर |
| 4 | excited | पिछले बंद भाव के मुकाबले | पिछले बंद भाव के मुकाबले |
| 4 | excited | पच्चीस फ़ीसदी से ज़्यादा चढ़ा। | 25% से ज़्यादा चढ़ा। |
| 5 | curious | उधर भारत में भी | उधर भारत में भी |
| 5 | curious | लोग एनवीडिया के शेयर | लोग एनवीडिया के शेयर |
| 5 | curious | का भाव खोज रहे थे। | का भाव खोज रहे थे। |
| 5 | curious | कर्नाटक में ख़ास दिलचस्पी दिखी। | कर्नाटक में ख़ास दिलचस्पी दिखी। |
| 6 | normal | गूगल ट्रेंड्स के मुताबिक, | गूगल ट्रेंड्स के मुताबिक, |
| 6 | normal | बीते चौबीस घंटों में | बीते 24 घंटों में |
| 6 | normal | इससे जुड़ी खोजें | इससे जुड़ी खोजें |
| 6 | normal | दो लाख से ज़्यादा थीं। | 2 लाख से ज़्यादा थीं। |

## दृश्य

| वाक्य | लेआउट | स्क्रीन | तथ्य |
|---|---|---|---|
| 1 | title_card | एनवीडिया · फिर बने सीईओ · जेनसन हुआंग की वापसी | G05 |
| 2, 3 | versus | एनवीडिया की कमान · 12 नवंबर इस्तीफ़े की घोषणा → 23 नवंबर सीईओ पद पर वापसी | G05, G06, G08 |
| 4 | hero_number | बाज़ार खुलने से पहले · 25% · से ज़्यादा उछाल · एनवीडिया का शेयर | G07 |
| 5 | title_card | गूगल ट्रेंड्स · भारत · एनवीडिया के शेयर का भाव · कर्नाटक में / ख़ास दिलचस्पी | G02, G04 |
| 6 | trend_card | 2 लाख+ · nvidia share price · खोजें · पिछले 24 घंटे · 24 नवंबर 2026 · 00:51 IST | G01, G02, G03, G09 |

पहले 0.30 सेकंड के लिए thumbnail.png का इस्तेमाल करें। trends_screenshot.png सत्यापन के लिए है। वीडियो में अपने ग्राफ़िक्स का इस्तेमाल करें।

## विवरण

जेनसन हुआंग की सीईओ पद पर वापसी के बाद भारत में एनवीडिया के शेयर की खोज क्यों बढ़ी? जानिए कंपनी की घोषणा, अमेरिकी बाज़ार खुलने से पहले शेयर में 25% से ज़्यादा की बढ़त और गूगल का खोज आँकड़ा।

कंपनी की घोषणा: 23 नवंबर 2026 (अमेरिकी प्रशांत समय)
रुझान की जाँच: 24 नवंबर 2026 (भारतीय समय)
गूगल ट्रेंड्स: https://trends.google.com/trending?geo=IN&status=active&sort=search-volume
एनवीडिया: https://investor.nvidia.com/news/press-release-details/2026/NVIDIA-Board-Reinstates-Jensen-Huang-as-President-CEO-and-Board-Director/default.aspx
मनीकंट्रोल हिंदी: https://hindi.moneycontrol.com/news/markets/nvidia-co-founder-jensen-huang-returns-as-ceo-with-shares-surging-over-30-percent-after-leadership-announcement-2473356.html

भारत में आज क्या चर्चा में है? रोज़ के छोटे अपडेट के लिए चैनल सब्सक्राइब करें।

#गूगलट्रेंड्स #एनवीडिया #शेयरबाज़ार #Shorts
प्री-मार्केट आँकड़े · ग्राफ़ा: https://grafa.com/en/news/united-states/nvidia-jumps-25-percent-after-jensen-huang-reinstatement
रॉयटर्स: https://www.investing.com/news/stock-market-news/nasdaq-futures-jump-6-as-nvidia-reinstates-jensen-huang-as-ceo-5045819

## पहला कमेंट

आपको किस बात ने ज़्यादा चौंकाया, सीईओ की वापसी या शेयरों की प्रतिक्रिया?

## स्रोत

- [Google Trends भारत](https://trends.google.com/trending?geo=IN&status=active&sort=search-volume)
- [एनवीडिया की आधिकारिक घोषणा](https://investor.nvidia.com/news/press-release-details/2026/NVIDIA-Board-Reinstates-Jensen-Huang-as-President-CEO-and-Board-Director/default.aspx)
- [मनीकंट्रोल हिंदी](https://hindi.moneycontrol.com/news/markets/nvidia-co-founder-jensen-huang-returns-as-ceo-with-shares-surging-over-30-percent-after-leadership-announcement-2473356.html)
- [इस्तीफ़े की घोषणा](https://nvidianews.nvidia.com/news/nvidia-announces-ceo-transition?frmapp=yes)
- [एसईसी फ़ॉर्म 8-के](https://www.sec.gov/Archives/edgar/data/1045810/000104581026000082/nvda-20261111.htm)
- [ग्राफ़ा](https://grafa.com/en/news/united-states/nvidia-jumps-25-percent-after-jensen-huang-reinstatement)
- [रॉयटर्स](https://www.investing.com/news/stock-market-news/nasdaq-futures-jump-6-as-nvidia-reinstates-jensen-huang-as-ceo-5045819)
- [स्टॉक एनालिसिस](https://stockanalysis.com/news/nvidia-reinstates-jensen-huang-as-ceo/)
